from setuptools import setup, find_packages

setup(name = 'ENSF 338 final project',
      version = '1.3',
      description = 'Final project package for ENSF 338',
      author = 'Oluwafisayo Adabs, Okibe Abang',
      author_email= 'okibzyabang@gmail.com, fizzyadabs@gmail.com',
      packages = find_packages(),
      install_requires = [],
      )